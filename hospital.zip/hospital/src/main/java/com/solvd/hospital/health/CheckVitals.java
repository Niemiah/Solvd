package com.solvd.hospital.health;
import com.solvd.hospital.people.Nurse;
public interface CheckVitals {

    public void checkVitals(Nurse nurse);
}
