package com.solvd.hospital.functional.interfaces;

//JDK Functional Interface
@FunctionalInterface
public interface IntPredicate {
    boolean test(int value);
}