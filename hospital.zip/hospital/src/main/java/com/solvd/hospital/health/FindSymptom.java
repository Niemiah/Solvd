package com.solvd.hospital.health;
import com.solvd.hospital.people.Patient;

public interface FindSymptom {
    public void giveSymptom(Patient patient, Symptom symptom);
}
