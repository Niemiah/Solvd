package com.solvd.hospital.exceptions;

public class InvalidBedException extends Exception{
    public InvalidBedException(String message) {
        super(message);
    }
}
