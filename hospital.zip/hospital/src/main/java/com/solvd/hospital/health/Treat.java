package com.solvd.hospital.health;
import com.solvd.hospital.people.Doctor;

public interface Treat {
    public void recommendTreatment(Doctor doctor);
}
