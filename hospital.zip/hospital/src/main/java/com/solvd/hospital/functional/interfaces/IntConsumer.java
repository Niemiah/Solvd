package com.solvd.hospital.functional.interfaces;

@FunctionalInterface
public interface IntConsumer {
    void accept(int value);
}